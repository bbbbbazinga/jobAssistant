import secrets
import sqlite3


def gen_token():
    token = secrets.token_hex(8)
    cursor = db.cursor()
    cursor.execute('SELECT TOKEN FROM USERS;')
    results = cursor.fetchall()
    results = list(results)
    tokens = []
    for result in results:
        tokens.append(result[0])
    while token in tokens:
        token = secrets.token_hex(8)
    return token


def gen_job_id():
    job_id = secrets.token_hex(8)
    cursor = db.cursor()
    cursor.execute('SELECT JOB_ID FROM JOBS;')
    results = cursor.fetchall()
    results = list(results)
    all_id = []
    for result in results:
        all_id.append(result[0])
    while job_id in all_id:
        job_id = secrets.token_hex(8)
    return job_id


def gen_app_id():
    app_id = secrets.token_hex(8)
    cursor = db.cursor()
    cursor.execute('SELECT APP_ID FROM APPLICATIONS;')
    results = cursor.fetchall()
    results = list(results)
    all_id = []
    for result in results:
        all_id.append(result[0])
    while app_id in all_id:
        app_id = secrets.token_hex(8)
    return app_id


# db = pymysql.connect("localhost", "root", "Srtao7070951121", "testdb")
db = sqlite3.connect('testdb', check_same_thread=False)
cursor = db.cursor()
# cursor.execute("DROP TABLE IF EXISTS USERS")
# cursor.execute("DROP TABLE IF EXISTS JOBS")
sql = """CREATE TABLE IF NOT EXISTS USERS (
            ROLE int DEFAULT NULL,
            TOKEN varchar(255) DEFAULT NULL,
            PASSWORD varchar(255) DEFAULT NULL,
            FIRST_NAME varchar(255) DEFAULT NULL,
            LAST_NAME varchar(255) DEFAULT NULL,
            GENDER varchar(255) DEFAULT NULL,
            BIRTH varchar(255) DEFAULT NULL,
            TELE varchar(255) DEFAULT NULL,
            EMAIL varchar(255) DEFAULT NULL,
            SRC text DEFAULT NULL,
            EXPECT_STATE varchar(255) DEFAULT NULL,
            SKILL varchar(255) DEFAULT NULL,
            SALARY varchar(255) DEFAULT NULL, 
            SCHOOL varchar(255) DEFAULT NULL, 
            MAJOR varchar(255) DEFAULT NULL,
            EDUR varchar(255) DEFAULT NULL,
            ELEVEL varchar(255) DEFAULT NULL,
            WAM varchar(255) DEFAULT NULL, 
            PNAME varchar(255) DEFAULT NULL,
            PROLE varchar(255) DEFAULT NULL, 
            PDUR varchar(255) DEFAULT NULL,
            PDES varchar(255) DEFAULT NULL,
            PNUM varchar(255) DEFAULT NULL,
            WCOM varchar(255) DEFAULT NULL,
            WPOS varchar(255) DEFAULT NULL,
            WDUR varchar(255) DEFAULT NULL,
            WDES varchar(255) DEFAULT NULL,
            INTRO varchar(255) DEFAULT NULL,
            COMPANY_NAME varchar(255) DEFAULT NULL,
            COMPANY_TYPE varchar(255) DEFAULT NULL,
            ABN varchar(255) DEFAULT NULL,
            POST_CODE varchar(255) DEFAULT NULL,
            COMPANY_DES text DEFAULT NULL,
            primary key (EMAIL)
        );"""
cursor.execute(sql)
sql = """CREATE TABLE IF NOT EXISTS JOBS (
            JOB_ID varchar(255) DEFAULT NULL,
            EMAIL varchar(255) DEFAULT NULL,
            COMPANY_NAME varchar(255) DEFAULT NULL,
            COMPANY_SCALE varchar(255) DEFAULT NULL,
            JTYPE varchar(255) DEFAULT NULL,
            TITLE varchar(255) DEFAULT NULL,
            RESPONSIBILITY text DEFAULT NULL,
            SKILL mediumtext DEFAULT NULL,
            EXPERIENCE text DEFAULT NULL,
            WORK_STATE varchar(255) DEFAULT NULL,
            WORK_LOCATION varchar(255) DEFAULT NULL,
            MIN_SALARY int DEFAULT NULL,
            MAX_SALARY int DEFAULT NULL,
            ETYPE varchar(255) DEFAULT NULL,
            DESCRIPTION text DEFAULT NULL,
            DEADLINE varchar(255) DEFAULT NULL,
            POST_TIME varchar(255) DEFAULT NULL,
            APPLICANT text DEFAULT NULL,
            primary key (JOB_ID),
            foreign key (EMAIL) references USERS (EMAIL) on delete cascade on update cascade      
        );"""
cursor.execute(sql)
sql = """CREATE TABLE IF NOT EXISTS APPLICATIONS (
            APP_ID varchar(255) DEFAULT NULL,
            JOB_ID varchar(255) DEFAULT NULL,
            EMAIL varchar(255) DEFAULT NULL,
            APP_TIME varchar(255) DEFAULT NULL,
            STATUS text DEFAULT NULL,
            ADDITIONAL_INPUT text DEFAULT NULL,
            RESPONSE text DEFAULT NULL, 
            OFFER text DEFAULT NULL,
            OFFER_NAME varchar(255) DEFAULT NULL,
            ADDITIONAL text DEFAULT NULL,
            ADDITIONAL_NAME varchar(255) DEFAULT NULL,
            primary key (APP_ID),
            foreign key (JOB_ID) references JOBS (JOB_ID) on delete cascade on update cascade,
            foreign key (EMAIL) references USERS (EMAIL) on delete cascade on update cascade 
        );"""
cursor.execute(sql)



