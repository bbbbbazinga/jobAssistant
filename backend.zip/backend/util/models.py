from app import api
from flask_restplus import fields

f = open('icon.txt')
icon = f.read()
token_details = api.model('token_details', {
    'token': fields.String(),
    'role': fields.Integer(),
    'email': fields.String()
})
job_id_details = api.model('job_id_details', {
    'job_id': fields.String()
})
login_details = api.model('login_details', {
  'email': fields.String(required=True, example='shenrongtao@gmail.com'),
  'password': fields.String(required=True, example='Srt951121.')
})
jobseeker_register_details = api.model('jobseeker_register_details', {
    'first_name': fields.String(required=True, example='Rongtao'),
    'last_name': fields.String(required=True, example='Shen'),
    'email': fields.String(required=True, example='shenrongtao@gmail.com'),
    'password': fields.String(required=True, example='Srt951121.'),
    'phone_number': fields.String(required=True, example='0410861121'),
})
employer_register_details = api.model('employer_register_details', {
    'first_name': fields.String(required=True, example='Rongtao'),
    'last_name': fields.String(required=True, example='Shen'),
    'coEmail': fields.String(required=True, example='shenrongtao@gmail.com'),
    'password': fields.String(required=True, example='Srt951121.'),
    'phoneNo': fields.String(required=True, example='0410861121'),
    'coName': fields.String(required=True, example='UNSW'),
    'ABN': fields.String(required=True, example='11111111111'),
    'post_code': fields.String(required=True, example='2036')
})
basic_info_details = api.model('basic_info_details', {
    'first_name': fields.String(required=True, example='Rongtao'),
    'last_name': fields.String(required=True, example='Shen'),
    'gender': fields.String(required=True, example='Men'),
    'birth': fields.String(required=True, example='21/11/95'),
    'tele': fields.String(required=True, example='0410861121'),
    'email': fields.String(required=True, example='shenrongtao@gmail.com'),
    'src': fields.String(required=True, example=icon),
    'expect_state': fields.String(required=True, example='NSW'),
    'skill': fields.String(required=True, example='Python'),
    'salary': fields.String(required=True, example='5000')
})
education_details = api.model('education_details', {
    'school': fields.String(required=True, example='UNSW'),
    'major': fields.String(required=True, example='Information Technology'),
    'EDur': fields.String(required=True, example='2 years'),
    'ELevel': fields.String(required=True, example='Master'),
    'wam': fields.String(required=True, example='77')
})
project_details = api.model('project_details', {
    'PName': fields.String(required=True, example='Object detection'),
    'PRole': fields.String(required=True, example='Group member'),
    'PDur': fields.String(required=True, example='2 months'),
    'PDes': fields.String(required=True, example='Good experience.'),
    'PNum': fields.String(required=True, example='3')
})
work_experience_details = api.model('work_experience_details', {
    'WCom': fields.String(required=True, example='Microsoft'),
    'WPos': fields.String(required=True, example='Software engineer'),
    'WDur': fields.String(required=True, example='3 months'),
    'WDes': fields.String(required=True, example='Good experience')
})
jobseeker_profile_details = api.model('jobseeker_profile_details', {
    'BI': fields.Nested(basic_info_details),
    'EE': fields.Nested(education_details),
    'PE': fields.Nested(project_details),
    'WE': fields.Nested(work_experience_details),
    'Intro': fields.String(required=True, example='I am good at Python.')
})
employer_profile_details = api.model('employer_profile_details', {
    'first_name': fields.String(required=True, example='Rongtao'),
    'last_name': fields.String(required=True, example='Shen'),
    'company_name': fields.String(required=True, example='Apple'),
    'company_type': fields.String(required=True, example='Technology and Internet'),
    'tele': fields.String(required=True, example='0410861121'),
    'email': fields.String(required=True, example='shenrongtao@gmail.com'),
    'ABN': fields.String(required=True, example='11111111111'),
    'post_code': fields.String(required=True, example='2036'),
    'company_des': fields.String(required=True, example='A multinational technology company')
})
post_job_details = api.model('post_job_details', {
    'company_name': fields.String(required=True, example='UNSW'),
    'company_scale': fields.String(required=True, example='Large'),
    'jtype': fields.String(required=True, example='Information Technology'),
    'title': fields.String(required=True, example='Test Engineer'),
    'responsibility': fields.String(required=True, example='test software'),
    'skill': fields.String(required=True, example='Python Shell'),
    'experience': fields.String(required=True, example='1-year develop experience'),
    'work_state': fields.String(required=True, example='NSW'),
    'work_location': fields.String(required=True, example='Sydney'),
    'min_salary': fields.Integer(required=True, example='2000'),
    'max_salary': fields.String(required=True, example='4000'),
    'etype': fields.String(required=True, example='Part-Time'),
    'description': fields.String(required=True, example='This is a good job!'),
    'deadline': fields.String(required=True, example='2020-12-02')
})
applicant_details = api.model('applicant_details', {
    'first_name': fields.String(required=True, example='Rongtao'),
    'last_name': fields.String(required=True, example='Shen'),
    'email': fields.String(required=True, example='shen@gmail.com'),
    'response': fields.String(required=True, exmaple='Interview accepted'),
    'addional': fields.String(),
    'additional_name': fields.String(),
    'score': fields.Integer()
})
job_details = api.model('job_details', {
    'job_id': fields.String(),
    'company_name': fields.String(required=True, example='UNSW'),
    'company_scale': fields.String(required=True, example='Large'),
    'jtype': fields.String(required=True, example='Information Technology'),
    'title': fields.String(required=True, example='Backend Engineer'),
    'responsibility': fields.String(required=True, example='backend develop'),
    'skill': fields.String(required=True, example='Python Flask'),
    'experience': fields.String(required=True, example='1-year develop experience'),
    'work_state': fields.String(required=True, example='NSW'),
    'work_location': fields.String(required=True, example='Sydney'),
    'min_salary': fields.Integer(required=True, example='5000'),
    'max_salary': fields.Integer(required=True, example='10000'),
    'etype': fields.String(required=True, example='Full-Time'),
    'description': fields.String(required=True, example='This is a good job!'),
    'deadline': fields.String(required=True, example='2020-11-21'),
    'post_time': fields.String(required=True, example='2020-10-28'),
    'applicant': fields.List(fields.Nested(applicant_details)),
    'status': fields.String(required=True, example='active/inactive')
})
job_posted_details = api.model('job_posted_details', {
    'posted': fields.List(fields.Nested(job_details))
})
seeker_apply_details = api.model('seeker_apply_details', {
    'job_id': fields.String(),
    'email': fields.String(required=True, example='shenrongtao@gmail.com')
})
apply_details = api.model('apply_details', {
    'job_id': fields.String(),
    'company_name': fields.String(required=True, example='UNSW'),
    'jtype': fields.String(required=True, example='Information Technology'),
    'title': fields.String(required=True, example='Backend Engineer'),
    'employer_email': fields.String(required=True, example='shenrongtao@gmail.com'),
    'app_time': fields.String(required=True, example='2020-11-01'),
    'additional_input': fields.String(required=True, example='Send me a new CV'),
    'status': fields.String(required=True, example='In Process'),
    'offer': fields.String(),
    'offer_name': fields.String()
})
my_application_details = api.model('my_application_details', {
    'applications': fields.List(fields.Nested(apply_details))
})
additional_input_details = api.model('additional_input_details', {
    'additional_input': fields.String()
})
interview_details = api.model('interview_details', {
    'date': fields.String()
})
response_details = api.model('response_details', {
    'response': fields.String(required=True, example='accept/decline')
})
decline_details = api.model('decline_details', {
    'decline': fields.String(required=True, example='decline')
})
offer_details = api.model('offer_details', {
    'offer': fields.String(),
    'offer_name': fields.String()
})
additional_file_details = api.model('addtional_file_details', {
    'additional': fields.String(),
    'additional_name': fields.String()
})

