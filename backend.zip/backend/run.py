from app import app
import util.database
import namespaces.auth
import namespaces.user
import namespaces.job
import namespaces.search
import namespaces.apply
app.run(debug=True)