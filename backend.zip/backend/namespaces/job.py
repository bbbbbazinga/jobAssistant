from flask_restplus import Resource
from flask import request
from util.models import *
from util.database import *
import json
from datetime import datetime

job = api.namespace('job', description='Post Job Services')


@job.route('/postJob', methods=['post'])
class Post(Resource):
    @job.response(200, 'Post job success', job_id_details)
    @job.response(400, 'Job posted')
    @job.response(403, 'Error')
    @job.param('email', 'employer email')
    @job.expect(post_job_details)
    @job.doc(description='This method is used to post a job')
    def post(self):
        email = request.args.get('email')
        data = json.loads(request.get_data())
        company_name = data['company_name']
        company_scale = data['company_scale']
        jtype = data['jtype']
        title = data['title']
        responsibility = data['responsibility']
        skill = data['skill']
        experience = data['experience']
        work_state = data['work_state']
        work_location = data['work_location']
        min_salary = data['min_salary']
        max_salary = data['max_salary']
        etype = data['etype']
        description = data['description']
        deadline = data['deadline']
        now = datetime.now()
        formatted_date = now.strftime('%Y-%m-%d')
        cursor = db.cursor()
        cursor.execute('SELECT EMAIL FROM USERS;')
        results = cursor.fetchall()
        results = list(results)
        emails = []
        for result in results:
            emails.append(result[0])
        if email not in emails:
            return {"message": "Invalid email."}, 403
        else:
            cursor.execute("SELECT COMPANY_NAME FROM USERS WHERE EMAIL = '{}';".format(email))
            company = cursor.fetchone()
            if company[0] != company_name:
                return {'message': "You are not able to post a job for other company."}, 403
            cursor.execute("SELECT TITLE FROM JOBS WHERE COMPANY_NAME = '{0}' AND JTYPE = '{1}';".format(company_name, jtype))
            results = cursor.fetchall()
            results = list(results)
            titles = []
            for result in results:
                titles.append(result[0])
            if title in titles:
                return {"message": "job has been posted."}, 400
            else:
                job_id = gen_job_id()
                cursor.execute("INSERT INTO JOBS (JOB_ID, EMAIL, COMPANY_NAME, COMPANY_SCALE, JTYPE, TITLE, \
                                RESPONSIBILITY, SKILL, EXPERIENCE, WORK_STATE, WORK_LOCATION, MIN_SALARY, MAX_SALARY, ETYPE, \
                                DESCRIPTION, DEADLINE, POST_TIME) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', \
                                '{6}', '{7}', '{8}', '{9}', '{10}', {11}, {12}, '{13}', '{14}', '{15}', '{16}');".format(\
                                job_id, email, company_name, company_scale, jtype, title, responsibility, skill, experience, work_state, work_location, int(min_salary), \
                                int(max_salary), etype, description, deadline, formatted_date))
                db.commit()
                return {
                    "job_id": job_id
                }, 200


@job.route('/jobPosted', methods=['GET', 'PUT', 'DELETE'])
class Jobs(Resource):
    @job.response(200, 'Success', job_posted_details)
    @job.response(403, 'Invalid email')
    @job.param('email', 'employer email')
    @job.doc(description='This method is used to return posted jobs list')
    def get(self):
        email = request.args.get('email')
        cursor = db.cursor()
        cursor.execute('SELECT EMAIL FROM USERS;')
        results = cursor.fetchall()
        results = list(results)
        emails = []
        for result in results:
            emails.append(result[0])
        if email not in emails:
            return {"message": "Invalid email."}, 403
        else:
            jobs_list = []
            columns = ['job_id', 'company_name', 'company_scale', 'jtype', 'title', 'responsibility', 'skill', 'experience', \
                           'work_state', 'work_location', 'min_salary', 'max_salary', 'etype', 'description', 'deadline', 'post_time', 'applicant', 'status']
            cursor.execute("SELECT JOB_ID, COMPANY_NAME, COMPANY_SCALE, JTYPE, TITLE, RESPONSIBILITY, SKILL, EXPERIENCE, WORK_STATE, \
                           WORK_LOCATION, MIN_SALARY, MAX_SALARY, ETYPE, DESCRIPTION, DEADLINE, POST_TIME, APPLICANT FROM JOBS WHERE \
                           EMAIL = '{}';".format(email))
            jobs = cursor.fetchall()
            for j in jobs:
                job_dict = {}
                i = 0
                for column in columns:
                    if column == 'min_salary' or column == 'max_salary':
                        job_dict[column] = str(j[i])
                        i += 1
                    elif column == 'applicant':
                        if j[i] == None:
                            job_dict[column] = None
                            i += 1
                        else:
                            applicants = j[i].split(', ')
                            applicants_info = []
                            for applicant in applicants:
                                score = 0
                                applicant_dict = {}
                                cursor.execute("SELECT FIRST_NAME, LAST_NAME FROM USERS WHERE EMAIL = '{}';".format(applicant))
                                name = cursor.fetchone()
                                applicant_dict['first_name'] = name[0]
                                applicant_dict['last_name'] = name[1]
                                applicant_dict['email'] = applicant
                                cursor.execute("SELECT RESPONSE, ADDITIONAL, ADDITIONAL_NAME FROM APPLICATIONS WHERE EMAIL = '{0}' AND JOB_ID = '{1}';".format(applicant, j[0]))
                                response = cursor.fetchone()
                                applicant_dict['response'] = response[0]
                                applicant_dict['additional'] = str(response[1]).lstrip("'").rstrip("'")
                                applicant_dict['additional_name'] = response[2]
                                # 匹配度排序
                                cursor.execute("SELECT EXPECT_STATE, SALARY, ELEVEL, PNUM FROM USERS WHERE EMAIL = '{}';".format(applicant))
                                element = cursor.fetchone()
                                if element[0] != None:
                                    if element[0] == j[8]:
                                        score += 5
                                if element[1] != None:
                                    if int(element[1]) >= int(j[10]) and int(element[1]) <= int(j[11]):
                                        score += 5
                                if element[2] != None:
                                    if element[2] == 'High School':
                                        score += 5
                                    elif element[2] == 'Bachelor':
                                        score += 10
                                    elif element[2] == 'Master':
                                        score += 15
                                    elif element[2] == 'PhD':
                                        score += 20
                                if element[3] != None:
                                    score += int(element[3])
                                applicant_dict['score'] = score
                                applicants_info.append(applicant_dict)
                            applicants_info = sorted(applicants_info, key=lambda k: k['score'], reverse=True)
                            new_applicants = []
                            if len(applicants_info) > 1:
                                for appli in applicants_info:
                                    new_applicants.append(appli['email'])
                                cursor.execute("UPDATE JOBS SET APPLICANT = '{0}' WHERE JOB_ID = '{1}';".format(', '.join(new_applicants), j[0]))
                                db.commit()
                            job_dict[column] = applicants_info
                            i += 1
                            # 匹配度排序
                    elif column == 'status':
                        now = datetime.now()
                        formatted_now = now.strftime('%Y-%m-%d')
                        if formatted_now <= j[14]:
                            job_dict[column] = 'active'
                            i += 1
                        else:
                            job_dict[column] = 'inactive'
                            i += 1
                    else:
                        job_dict[column] = j[i]
                        i += 1
                jobs_list.append((job_dict))
            jobs_list = sorted(jobs_list, key=lambda k: k['post_time'], reverse=True)
            return {
                "posted": jobs_list
            }, 200

    @job.response(200, 'Success')
    @job.response(403, 'Invalid job id')
    @job.param('job_id', 'Job ID')
    @job.expect(post_job_details)
    @job.doc(description="This method is used to update posted job's details")
    def put(self):
        job_id = request.args.get('job_id')
        data = json.loads(request.get_data())
        cursor = db.cursor()
        cursor.execute('SELECT JOB_ID FROM JOBS;')
        results = cursor.fetchall()
        results = list(results)
        all_id = []
        for result in results:
            all_id.append(result[0])
        if job_id not in all_id:
            return {"message": "Invalid job id."}, 403
        else:
            keys = data.keys()
            if len(keys) == 0:
                return {"message": "job details have already been updated."}, 200
            else:
                for key in keys:
                    if key == 'min_salary' or key == 'max_salary':
                        cursor.execute("UPDATE JOBS SET {0} = {1} WHERE JOB_ID = '{2}';".format(key, int(data[key]), job_id))
                        db.commit()
                    else:
                        cursor.execute("UPDATE JOBS SET {0} = '{1}' WHERE JOB_ID = '{2}';".format(key, data[key], job_id))
                        db.commit()
                return {"message": "job details updated."}, 200


    @job.response(200, 'Success')
    @job.response(403, 'Invalid job id')
    @job.param('job_id', 'Job ID')
    @job.doc(description='This method is used to delete a job.')
    def delete(self):
        job_id = request.args.get('job_id')
        cursor = db.cursor()
        cursor.execute('SELECT JOB_ID FROM JOBS;')
        results = cursor.fetchall()
        results = list(results)
        all_id = []
        for result in results:
            all_id.append(result[0])
        if job_id not in all_id:
            return {"message": "Invalid job id."}, 403
        else:
            cursor.execute("DELETE FROM JOBS WHERE JOB_ID = '{}';".format(job_id))
            db.commit()
            return {"message": "The job has been deleted."}, 200


@job.route('/eachJob', methods=['GET', 'PUT'])
class GetID(Resource):
    @job.response(200, 'Success', job_posted_details)
    @job.response(403, 'No related job id')
    @job.param('email', 'Employer email')
    @job.param('title', 'Title')
    @job.param('jtype', 'Job type')
    @job.doc(description='This method is used to get job id.')
    def get(self):
        email = request.args.get('email')
        title = request.args.get('title')
        jtype = request.args.get('jtype')
        columns = ['job_id', 'company_name', 'company_scale', 'jtype', 'title', 'responsibility', 'skill', 'experience', \
                   'work_state', 'work_location', 'min_salary', 'max_salary', 'etype', 'description', 'deadline', \
                   'post_time', 'applicant', 'status']
        cursor = db.cursor()
        cursor.execute("SELECT JOB_ID, COMPANY_NAME, COMPANY_SCALE, JTYPE, TITLE, RESPONSIBILITY, SKILL, EXPERIENCE, \
                        WORK_STATE, WORK_LOCATION, MIN_SALARY, MAX_SALARY, ETYPE, DESCRIPTION, DEADLINE, POST_TIME, APPLICANT FROM JOBS WHERE EMAIL = '{0}' AND TITLE = '{1}' AND JTYPE = '{2}';".format(email, title, jtype))
        result = cursor.fetchone()
        if result == None:
            return {"message": "No related job id."}, 403
        else:
            job_list = []
            job_dict = {}
            i = 0
            for column in columns:
                if column == 'applicant':
                    if result[i] == None:
                        job_dict[column] = None
                        i += 1
                    else:
                        applicants = result[i].split(', ')
                        applicants_info = []
                        for applicant in applicants:
                            score = 0
                            applicant_dict = {}
                            cursor.execute("SELECT FIRST_NAME, LAST_NAME FROM USERS WHERE EMAIL = '{}';".format(applicant))
                            name = cursor.fetchone()
                            applicant_dict['first_name'] = name[0]
                            applicant_dict['last_name'] = name[1]
                            applicant_dict['email'] = applicant
                            cursor.execute("SELECT RESPONSE, ADDITIONAL, ADDITIONAL_NAME FROM APPLICATIONS WHERE EMAIL = '{0}' AND JOB_ID = '{1}';".format(applicant, result[0]))
                            response = cursor.fetchone()
                            applicant_dict['response'] = response[0]
                            applicant_dict['additional'] = str(response[1]).lstrip("'").rstrip("'")
                            applicant_dict['additional_name'] = response[2]
                            # 匹配度排序
                            cursor.execute("SELECT EXPECT_STATE, SALARY, ELEVEL, PNUM FROM USERS WHERE EMAIL = '{}';".format(applicant))
                            element = cursor.fetchone()
                            if element[0] != None:
                                if element[0] == result[8]:
                                    score += 5
                            if element[1] != None:
                                if int(element[1]) >= int(result[10]) and int(element[1]) <= int(result[11]):
                                    score += 5
                            if element[2] != None:
                                if element[2] == 'High School':
                                    score += 5
                                elif element[2] == 'Bachelor':
                                    score += 10
                                elif element[2] == 'Master':
                                    score += 15
                                elif element[2] == 'PhD':
                                    score += 20
                            if element[3] != None:
                                score += int(element[3])
                            applicant_dict['score'] = score
                            applicants_info.append(applicant_dict)
                        applicants_info = sorted(applicants_info, key=lambda k: k['score'], reverse=True)
                        job_dict[column] = applicants_info
                        i += 1
                elif column == 'status':
                    now = datetime.now()
                    formatted_now = now.strftime('%Y-%m-%d')
                    if formatted_now <= result[14]:
                        job_dict[column] = 'active'
                        i += 1
                    else:
                        job_dict[column] = 'inactive'
                        i += 1
                else:
                    job_dict[column] = result[i]
                    i += 1
            job_list.append(job_dict)
            return {
                "posted": job_list
            }, 200

    @job.response(200, 'Success')
    @job.response(403, 'Invalid Email or Job ID')
    @job.param('email', 'seeker email')
    @job.param('job_id', 'job id')
    @job.expect(additional_input_details)
    @job.doc(description='This method is used to notice job seeker to submit additional input.')
    def put(self):
        email = request.args.get('email')
        job_id = request.args.get('job_id')
        data = json.loads(request.get_data())
        additional_input = data['additional_input']
        cursor = db.cursor()
        cursor.execute("SELECT APP_ID FROM APPLICATIONS WHERE EMAIL = '{0}' AND JOB_ID = '{1}';".format(email, job_id))
        app_id = cursor.fetchone()
        if app_id == None:
            return {"message": "Invalid job seeker email or job id."}, 403
        else:
            cursor.execute("UPDATE APPLICATIONS SET ADDITIONAL_INPUT = '{0}' WHERE EMAIL = '{1}' AND JOB_ID = '{2}';".format(additional_input, email, job_id))
            db.commit()
            return {"message": "additional input updated."}, 200


@job.route('/sendInterview', methods=['PUT'])
class Interview(Resource):
    @job.response(200, 'Success')
    @job.response(403, 'Invalid seeker email or job id')
    @job.param('email', 'seeker email')
    @job.param('job_id', 'job id')
    @job.expect(interview_details)
    @job.doc(description='This method is used to send interview invitation to the applicant. The interview date should be selected')
    def put(self):
        email = request.args.get('email')
        job_id = request.args.get('job_id')
        data = json.loads(request.get_data())
        interview_date = data['date']
        status = "The interview will be held on {}. Please attend on time.".format(interview_date)
        cursor = db.cursor()
        cursor.execute("SELECT APP_ID FROM APPLICATIONS WHERE EMAIL = '{}' AND JOB_ID = '{}';".format(email, job_id))
        app_id = cursor.fetchone()
        if app_id == None:
            return {"message": "Invalid job seeker email or job id."}, 403
        else:
            cursor.execute("UPDATE APPLICATIONS SET STATUS = '{0}' WHERE EMAIL = '{1}' AND JOB_ID = '{2}';".format(status, email, job_id))
            db.commit()
            return {"message": "The interview invitation has been sent."}, 200


@job.route('/sendXInterviews', methods=['PUT'])
class Interviews(Resource):
    @job.response(200, 'Success')
    @job.response(400, 'Incorrect applicant number or no applicant')
    @job.response(403, 'Invalid job id')
    @job.param('job_id', 'job id')
    @job.param('num', 'the number of invitations')
    @job.expect(interview_details)
    @job.doc(description='This method is used to send X interview invitations to X applicants.')
    def put(self):
        job_id = request.args.get('job_id')
        num = request.args.get('num')
        if num == '' or num.startswith('-'):
            return {"message": "You should enter a correct number."}, 400
        num = int(num)
        cursor = db.cursor()
        cursor.execute("SELECT APPLICANT FROM JOBS WHERE JOB_ID = '{}';".format(job_id))
        result = cursor.fetchone()
        if result[0] == None:
            return {"message": "No applicant."}, 400
        applicants = result[0].split(', ')
        if num == 0 or num > len(applicants):
            return {"message": "You should enter a correct number"}, 400
        data = json.loads(request.get_data())
        interview_date = data['date']
        if interview_date == '':
            return {"message": 'Please select the interview date.'}, 400
        status = "The interview will be held on {}. Please attend on time.".format(interview_date)
        cursor.execute("SELECT JOB_ID FROM JOBS;")
        all_id = cursor.fetchall()
        if job_id not in [i[0] for i in all_id]:
            return {"message": "Invalid job id"}, 403
        cursor.execute("SELECT APPLICANT FROM JOBS WHERE JOB_ID = '{}';".format(job_id))
        applicant_string = cursor.fetchone()
        applicants = applicant_string[0].split(', ')
        applicants = applicants[: num]
        for applicant in applicants:
            cursor.execute("UPDATE APPLICATIONS SET STATUS = '{0}' WHERE EMAIL = '{1}' AND JOB_ID = '{2}';".format(status, applicant, job_id))
            db.commit()
        return {"message": "The interview invitations have been sent."}, 200


@job.route('/sendOffer', methods=['PUT'])
class Offer(Resource):
    @job.response(200, 'Success')
    @job.response(403, 'Invalid seeker email or job id')
    @job.param('email', 'seeker email')
    @job.param('job_id', 'job id')
    @job.expect(offer_details)
    @job.doc(description='This method is used to send offer to the applicant.')
    def put(self):
        email = request.args.get('email')
        job_id = request.args.get('job_id')
        data = json.loads(request.get_data())
        offer = data['offer']
        offer_name = data['offer_name']
        status = 'There is an offer in your attachment file, please check it.'
        cursor = db.cursor()
        cursor.execute("SELECT APP_ID FROM APPLICATIONS WHERE EMAIL = '{0}' AND JOB_ID = '{1}';".format(email, job_id))
        app_id = cursor.fetchone()
        if app_id == None:
            return {"message": "Invalid job seeker email or job id."}, 403
        else:
            cursor.execute("UPDATE APPLICATIONS SET STATUS = '{0}', OFFER = '{1}', OFFER_NAME = '{2}' WHERE EMAIL = '{3}' AND JOB_ID = '{4}';".format(status, offer, offer_name, email, job_id))
            db.commit()
            return {"message": "The offer has been sent successfully."}, 200



@job.route('/sendDecline', methods=['PUT'])
class Decline(Resource):
    @job.response(200, 'Success')
    @job.response(400, 'Error')
    @job.response(403, 'Invalid seeker email or job id')
    @job.param('email', 'seeker email')
    @job.param('job_id', 'job id')
    @job.expect(decline_details)
    @job.doc(description="This method is used to decline applicant's application.")
    def put(self):
        email = request.args.get('email')
        job_id = request.args.get('job_id')
        data = json.loads(request.get_data())
        decline = data['decline']
        status = 'Unfortunately, you did not pass our assessment. Thanks for your application.'
        cursor = db.cursor()
        cursor.execute("SELECT APP_ID FROM APPLICATIONS WHERE EMAIL = '{0}' AND JOB_ID = '{1}';".format(email, job_id))
        app_id = cursor.fetchone()
        if app_id == None:
            return {"message": "Invalid job seeker email or job id."}, 403
        else:
            if decline == 'decline':
                cursor.execute("UPDATE APPLICATIONS SET STATUS = '{0}' WHERE EMAIL = '{1}' AND JOB_ID = '{2}';".format(status, email, job_id))
                db.commit()
                cursor.execute("SELECT APPLICANT FROM JOBS WHERE JOB_ID = '{}';".format(job_id))
                result = cursor.fetchone()
                applicants = result[0].split(', ')
                applicants.remove(email)
                if len(applicants) == 0:
                    cursor.execute("UPDATE JOBS SET APPLICANT = NULL WHERE JOB_ID = '{}';".format(job_id))
                    db.commit()
                else:
                    applicants_string = ', '.join(applicants)
                    cursor.execute("UPDATE JOBS SET APPLICANT = '{0}' WHERE JOB_ID = '{1}';".format(applicants_string, job_id))
                    db.commit()
                return {"message": "Status updated."}, 200
            else:
                return {"message": "Error"}, 400


