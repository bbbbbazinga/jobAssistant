from flask_restplus import Resource
from flask import request
from util.models import *
from util.database import *
import json
from datetime import datetime

apply = api.namespace('apply', 'Apply Job Service')


@apply.route('/positionInformation', methods=['PUT'])
class Apply(Resource):
    @apply.response(200, 'Success')
    @apply.response(400, 'Already apply')
    @apply.response(403, 'No Login or Register')
    @apply.expect(seeker_apply_details)
    @apply.doc(description='This method is used to apply a job.')
    def put(self):
        data = json.loads(request.get_data())
        job_id = data['job_id']
        email = data['email']
        cursor = db.cursor()
        cursor.execute("SELECT * FROM USERS WHERE EMAIL = '{}';".format(email))
        result = cursor.fetchone()
        if result == None:
            return {"message": "Please login or register first."}, 403
        else:
            app_id = gen_app_id()
            now = datetime.now()
            app_time = now.strftime('%Y-%m-%d')
            status = 'In Process'
            cursor.execute("SELECT APPLICANT FROM JOBS WHERE JOB_ID = '{}';".format(job_id))
            applicants = cursor.fetchone()
            if applicants[0] == None:
                cursor.execute("UPDATE JOBS SET APPLICANT = '{0}' WHERE JOB_ID = '{1}';".format(email, job_id))
                db.commit()
                cursor.execute("INSERT INTO APPLICATIONS (APP_ID, JOB_ID, EMAIL, APP_TIME, STATUS) \
                                VALUES ('{0}', '{1}', '{2}', '{3}', '{4}');".format(app_id, job_id, email, app_time, status))
                db.commit()
                return {"message": "Apply job successfully."}, 200
            else:
                if email in str(applicants[0]):
                    return {"message": "You have already applied this job."}, 400
                else:
                    new_applicants = str(applicants[0]) + ', ' + email
                    cursor.execute("UPDATE JOBS SET APPLICANT = '{0}' WHERE JOB_ID = '{1}';".format(new_applicants, job_id))
                    db.commit()
                    cursor.execute("INSERT INTO APPLICATIONS (APP_ID, JOB_ID, EMAIL, APP_TIME, STATUS) \
                                    VALUES ('{0}', '{1}', '{2}', '{3}', '{4}');".format(app_id, job_id, email, app_time, status))
                    db.commit()
                    return {"message": "Apply job successfully."}, 200


@apply.route('/applicantInformation', methods=['GET'])
class Applicant(Resource):
    @apply.response(200, 'Success', jobseeker_profile_details)
    @apply.response(403, 'Invalid email')
    @apply.param('email', 'Applicant Email')
    @apply.doc(description="This method is used to return applicant's information.")
    def get(self):
        email = request.args.get('email')
        cursor = db.cursor()
        cursor.execute("SELECT * FROM USERS WHERE EMAIL = '{}';".format(email))
        result = cursor.fetchone()
        if result == None:
            return {"message": "Invalid email."}, 403
        else:
            return {
                       'BI': {
                           'first_name': result[3],
                           'last_name': result[4],
                           'gender': result[5],
                           'birth': result[6],
                           'tele': result[7],
                           'email': result[8],
                           'src': str(result[9]).lstrip("'").rstrip("'"),
                           'expect_state': result[10],
                           'skill': result[11],
                           'salary': result[12]
                       },
                       'EE': {
                           'school': result[13],
                           'major': result[14],
                           'EDur': result[15],
                           'ELevel': result[16],
                           'wam': result[17]
                       },
                       'PE': {
                           'PName': result[18],
                           'PRole': result[19],
                           'PDur': result[20],
                           'PDes': result[21],
                           'PNum': result[22]
                       },
                       'WE': {
                           'WCom': result[23],
                           'WPos': result[24],
                           'WDur': result[25],
                           'WDes': result[26]
                       },
                       'Intro': result[27]
                   }, 200


@apply.route('/myApplication', methods=['GET', 'PUT'])
class Application(Resource):
    @apply.response(200, 'Success', my_application_details)
    @apply.response(403, 'No application')
    @apply.param('email', 'Applicant Email')
    @apply.doc(description="This method is used to return user's application detail.")
    def get(self):
        email = request.args.get('email')
        cursor = db.cursor()
        cursor.execute("SELECT JOB_ID FROM APPLICATIONS WHERE EMAIL = '{}'".format(email))
        results = cursor.fetchall()
        if len(results) == 0:
            return {"message": "No application"}, 403
        else:
            application_list = []
            all_job_id = []
            for result in results:
                all_job_id.append(result[0])
            for id in all_job_id:
                cursor.execute("SELECT APP_TIME, STATUS, ADDITIONAL_INPUT, OFFER, OFFER_NAME FROM APPLICATIONS WHERE EMAIL = '{0}' AND JOB_ID = '{1}';".format(email, id))
                data = cursor.fetchone()
                app_time = data[0]
                status = data[1]
                additional_input = data[2]
                offer = str(data[3]).lstrip("'").rstrip("'")
                offer_name = data[4]
                cursor.execute("SELECT EMAIL, COMPANY_NAME, JTYPE, TITLE FROM JOBS WHERE JOB_ID = '{}';".format(id))
                row = cursor.fetchone()
                application_dict = {}
                application_dict['job_id'] = id
                application_dict['company_name'] = row[1]
                application_dict['jtype'] = row[2]
                application_dict['title'] = row[3]
                application_dict['employer_email'] = row[0]
                application_dict['app_time'] = app_time
                application_dict['additional_input'] = additional_input
                application_dict['status'] = status
                application_dict['offer'] = offer
                application_dict['offer_name'] = offer_name
                application_list.append(application_dict)
            return {
                "applications": application_list
            }, 200

    @apply.response(200, 'Success')
    @apply.response(403, 'Invalid seeker email or job id')
    @apply.param('email', 'seeker email')
    @apply.param('job_id', 'job id')
    @apply.expect(additional_file_details)
    def put(self):
        email = request.args.get('email')
        job_id = request.args.get('job_id')
        data = json.loads(request.get_data())
        additional = data['additional']
        additional_name = data['additional_name']
        cursor = db.cursor()
        cursor.execute("SELECT APP_ID FROM APPLICATIONS WHERE EMAIL = '{0}' AND JOB_ID = '{1}';".format(email, job_id))
        app_id = cursor.fetchone()
        if app_id == None:
            return {"message": "Invalid seeker email or job id."}, 403
        else:
            cursor.execute("UPDATE APPLICATIONS SET ADDITIONAL = '{0}', ADDITIONAL_NAME = '{1}' WHERE EMAIL = '{2}' AND JOB_ID = '{3}';".format(additional, additional_name, email, job_id))
            db.commit()
            return {"message": "Your additional file has been uploaded successfully."}, 200


@apply.route('/sendResponse', methods=['PUT'])
class Response(Resource):
    @apply.response(200, 'Success')
    @apply.response(400, 'Error')
    @apply.response(403, 'Invalid seeker email or job id')
    @apply.param('email', 'seeker email')
    @apply.param('job_id', 'job id')
    @apply.expect(response_details)
    @apply.doc(description='This method is used to accept or decline interview invitations or offers')
    def put(self):
        email = request.args.get('email')
        job_id = request.args.get('job_id')
        data = json.loads(request.get_data())
        response = data['response']
        cursor = db.cursor()
        cursor.execute("SELECT APP_ID FROM APPLICATIONS WHERE EMAIL = '{0}' AND JOB_ID = '{1}';".format(email, job_id))
        app_id = cursor.fetchone()
        if app_id == None:
            return {"message": "Invalid seeker email or job id."}, 403
        else:
            cursor.execute("SELECT STATUS, RESPONSE FROM APPLICATIONS WHERE EMAIL = '{}' AND JOB_ID = '{}';".format(email, job_id))
            result = cursor.fetchone()
            status = result[0]
            curr_response = result[1]
            if status == 'In Process':
                return {"message": "Your application is being processed, you can not do this operation."}, 400
            elif 'interview' in status:
                if response == 'accept':
                    if curr_response == None:
                        response_text = 'Interview accepted.'
                        cursor.execute("UPDATE APPLICATIONS SET RESPONSE = '{0}' WHERE EMAIL = '{1}' AND JOB_ID = '{2}';".format(response_text, email, job_id))
                        db.commit()
                        return {"message": "The response has been updated."}, 200
                    else:
                        if 'accepted' in curr_response:
                            return {"message": "You have already accepted, you can not change your choice."}, 400
                        else:
                            return {"message": "You have already declined, you can not change your choice."}, 400
                else:
                    if curr_response == None:
                        response_text = 'Interview declined.'
                        cursor.execute("UPDATE APPLICATIONS SET RESPONSE = '{0}' WHERE EMAIL = '{1}' AND JOB_ID = '{2}';".format(response_text, email, job_id))
                        db.commit()
                        return {"message": "The response has been updated."}, 200
                    else:
                        if 'accepted' in curr_response:
                            return {"message": "You have already accepted, you can not change your choice."}, 400
                        else:
                            return {"message": "You have already declined, you can not change your choice."}, 400
            elif 'Unfortunately' in status:
                return {"message": "You have been declined. You can not do this operation."}, 400
            elif 'offer' in status:
                if response == 'accept':
                    if curr_response == None or 'Offer' not in curr_response:
                        response_text = 'Offer accepted.'
                        cursor.execute("UPDATE APPLICATIONS SET RESPONSE = '{0}' WHERE EMAIL = '{1}' AND JOB_ID = '{2}';".format(response_text, email, job_id))
                        db.commit()
                        return {"message": "The response has been updated."}, 200
                    else:
                        if 'accepted' in curr_response:
                            return {"message": "You have already accepted, you can not change your choice."}, 400
                        else:
                            return {"message": "You have already declined, you can not change your choice."}, 400
                else:
                    if curr_response == None or 'Offer' not in curr_response:
                        response_text = 'Offer declined.'
                        cursor.execute("UPDATE APPLICATIONS SET RESPONSE = '{0}' WHERE EMAIL = '{1}' AND JOB_ID = '{2}';".format(response_text, email, job_id))
                        db.commit()
                        return {"message": "The response has been updated."}, 200
                    else:
                        if 'accepted' in curr_response:
                            return {"message": "You have already accepted, you can not change your choice."}, 400
                        else:
                            return {"message": "You have already declined, you can not change your choice."}, 400









