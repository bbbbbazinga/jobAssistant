from flask_restplus import Resource
from flask import request
from util.models import *
from util.database import *
from datetime import datetime

search = api.namespace('search', 'Search Job Services')


@search.route('/searchJob', methods=['GET'])
class Search(Resource):
    @search.response(200, 'Success', job_posted_details)
    @search.response(400, 'No result')
    @search.response(403, 'No keywords')
    @search.param('jtype', 'Job Type')
    @search.param('keyword', 'Keyword')  # Backend Engineer
    @search.param('etype', 'Employerment Type')  # Full-Time
    @search.param('company_scale', 'Company Scale')  # Large
    @search.param('work_state', 'Work State')  # NSW
    @search.param('min_salary', 'Minimum Salary')  # 5000
    @search.param('max_salary', 'Maximum Salary')  # 10000
    @search.param('sorted_by', 'Sorted by')  # post_time or deadline or min_salary or max_salary
    @search.doc(description='This method is used to search jobs.')
    def get(self):
        now = datetime.now()
        formatted_now = now.strftime('%Y-%m-%d')
        cursor = db.cursor()
        columns = ['job_id', 'company_name', 'company_scale', 'jtype', 'title', 'responsibility', 'skill', 'experience', \
                   'work_state', 'work_location', 'min_salary', 'max_salary', 'etype', 'description', 'deadline',
                   'post_time']
        sorted_by = request.args.get('sorted_by')
        queries = ['jtype', 'keyword', 'etype', 'company_scale', 'work_state', 'min_salary', 'max_salary']
        conditions = {}
        for query in queries:
            condition = request.args.get(query)
            if condition != None:
                conditions[query] = condition
        keys = conditions.keys()
        if len(keys) == 0:
            cursor.execute("SELECT JOB_ID, COMPANY_NAME, COMPANY_SCALE, JTYPE, TITLE, RESPONSIBILITY, SKILL, EXPERIENCE, WORK_STATE, \
                                    WORK_LOCATION, MIN_SALARY, MAX_SALARY, ETYPE, DESCRIPTION, DEADLINE, POST_TIME FROM JOBS;")
            jobs = cursor.fetchall()
            jobs_list = []
            for job in jobs:
                job_dict = {}
                i = 0
                for column in columns:
                    job_dict[column] = job[i]
                    i += 1
                if formatted_now <= job_dict['deadline']:
                    jobs_list.append(job_dict)
            if len(jobs_list) == 0:
                return {"message": "No related jobs."}, 400
            else:
                if sorted_by == None:
                    return {
                               "posted": jobs_list
                           }, 200
                elif sorted_by == 'max_salary' or sorted_by == 'post_time':
                    jobs_list = sorted(jobs_list, key=lambda k: k[sorted_by], reverse=True)
                else:
                    jobs_list = sorted(jobs_list, key=lambda k: k[sorted_by])
                return {
                           "posted": jobs_list
                       }, 200
        else:
            if 'keyword' not in keys:
                condition_list = []
                for key in keys:
                    if key == 'min_salary':
                        condition_list.append('min_salary >= {}'.format(int(conditions[key])))
                    elif key == 'max_salary':
                        condition_list.append('max_salary <= {}'.format(int(conditions[key])))
                    else:
                        condition_list.append("{0} = '{1}'".format(key, conditions[key]))
                condition_string = ' and '.join(condition_list)
                cursor.execute("SELECT JOB_ID, COMPANY_NAME, COMPANY_SCALE, JTYPE, TITLE, RESPONSIBILITY, SKILL, EXPERIENCE, WORK_STATE, \
                                WORK_LOCATION, MIN_SALARY, MAX_SALARY, ETYPE, DESCRIPTION, DEADLINE, POST_TIME FROM JOBS WHERE {};".format(condition_string))
                jobs = cursor.fetchall()
                jobs_list = []
                for job in jobs:
                    job_dict = {}
                    i = 0
                    for column in columns:
                        job_dict[column] = job[i]
                        i += 1
                    if formatted_now <= job_dict['deadline']:
                        jobs_list.append(job_dict)
                if len(jobs_list) == 0:
                    return {"message": "No related jobs."}, 400
                else:
                    if sorted_by == None:
                        return {
                                   "posted": jobs_list
                               }, 200
                    elif sorted_by == 'max_salary' or sorted_by == 'post_time':
                        jobs_list = sorted(jobs_list, key=lambda k: k[sorted_by], reverse=True)
                    else:
                        jobs_list = sorted(jobs_list, key=lambda k: k[sorted_by])
                    return {
                               "posted": jobs_list
                           }, 200
            else:
                keyword = ''
                condition_list = []
                for key in keys:
                    if key == 'keyword':
                        keyword = conditions['keyword'].lower()
                    elif key == 'min_salary':
                        condition_list.append('min_salary >= {}'.format(int(conditions[key])))
                    elif key == 'max_salary':
                        condition_list.append('max_salary <= {}'.format(int(conditions[key])))
                    else:
                        condition_list.append("{0} = '{1}'".format(key, conditions[key]))
                if len(condition_list) == 0:
                    cursor.execute("SELECT JOB_ID, COMPANY_NAME, COMPANY_SCALE, JTYPE, TITLE, RESPONSIBILITY, SKILL, EXPERIENCE, WORK_STATE, \
                                    WORK_LOCATION, MIN_SALARY, MAX_SALARY, ETYPE, DESCRIPTION, DEADLINE, POST_TIME FROM JOBS;")
                else:
                    condition_string = ' and '.join(condition_list)
                    cursor.execute("SELECT JOB_ID, COMPANY_NAME, COMPANY_SCALE, JTYPE, TITLE, RESPONSIBILITY, SKILL, EXPERIENCE, WORK_STATE, \
                                    WORK_LOCATION, MIN_SALARY, MAX_SALARY, ETYPE, DESCRIPTION, DEADLINE, POST_TIME FROM JOBS WHERE {};".format(condition_string))
                jobs = cursor.fetchall()
                jobs_list = []
                for job in jobs:
                    job_dict = {}
                    i = 0
                    for column in columns:
                        job_dict[column] = job[i]
                        i += 1
                    if formatted_now <= job_dict['deadline']:
                        jobs_list.append(job_dict)
                jobs_list = list(filter(lambda x: keyword in x['title'].lower() or keyword in x['description'].lower() or keyword in x['responsibility'].lower() or keyword in x['skill'].lower(), jobs_list))
                if len(jobs_list) == 0:
                    return {"message": "No related jobs."}, 400
                else:
                    if sorted_by == None:
                        return {
                                   "posted": jobs_list
                               }, 200
                    elif sorted_by == 'max_salary' or sorted_by == 'post_time':
                        jobs_list = sorted(jobs_list, key=lambda k: k[sorted_by], reverse=True)
                    else:
                        jobs_list = sorted(jobs_list, key=lambda k: k[sorted_by])
                    return {
                               "posted": jobs_list
                           }, 200


@search.route('/positionInformation', methods=['GET'])
class Information(Resource):
    @search.response(200, 'Success', job_details)
    @search.response(403, 'Invalid job id')
    @search.param('job_id', 'Job ID')
    @search.doc(description='This method is used to return certain job details.')
    def get(self):
        columns = ['job_id', 'company_name', 'company_scale', 'jtype', 'title', 'responsibility', 'skill', 'experience', \
                   'work_state', 'work_location', 'min_salary', 'max_salary', 'etype', 'description', 'deadline',
                   'post_time']
        job_id = request.args.get('job_id')
        cursor = db.cursor()
        cursor.execute('SELECT JOB_ID FROM JOBS;')
        results = cursor.fetchall()
        results = list(results)
        all_id = []
        for result in results:
            all_id.append(result[0])
        if job_id not in all_id:
            return {"message": "Invalid job id."}, 403
        else:
            cursor.execute("SELECT JOB_ID, COMPANY_NAME, COMPANY_SCALE, JTYPE, TITLE, RESPONSIBILITY, SKILL, EXPERIENCE, WORK_STATE, \
                            WORK_LOCATION, MIN_SALARY, MAX_SALARY, ETYPE, DESCRIPTION, DEADLINE, POST_TIME FROM JOBS WHERE JOB_ID = '{}';".format(job_id))
            detail = cursor.fetchone()
            detail_dict = {}
            i = 0
            for column in columns:
                detail_dict[column] = detail[i]
                i += 1
            return detail_dict, 200