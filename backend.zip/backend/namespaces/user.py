from flask_restplus import Resource
from flask import request
from util.models import *
from util.database import *
import json

seeker = api.namespace('seeker', description='Job Seeker Information Services')
employer = api.namespace('employer', description='Employer Information Services')


@seeker.route('/seekerPage', methods=['GET', 'PUT'])
class Seeker(Resource):
    @seeker.response(200, 'Success', jobseeker_profile_details)
    @seeker.response(403, 'Invalid Auth Token')
    @seeker.param('token', 'Auth Token')
    @seeker.doc(description="This method is used to get the job seeker's profile details from the server")
    def get(self):
        token = request.args.get('token')
        cursor = db.cursor()
        cursor.execute("SELECT * FROM USERS WHERE TOKEN = '{}';".format(token))
        row = cursor.fetchone()
        if row == None:
            return {"message": 'Invalid Token'}, 403
        else:
            return {
                'BI': {
                    'first_name': row[3],
                    'last_name': row[4],
                    'gender': row[5],
                    'birth': row[6],
                    'tele': row[7],
                    'email': row[8],
                    'src': str(row[9]).lstrip("'").rstrip("'"),
                    'expect_state': row[10],
                    'skill': row[11],
                    'salary': row[12]
                },
                'EE': {
                    'school': row[13],
                    'major': row[14],
                    'EDur': row[15],
                    'ELevel': row[16],
                    'wam': row[17]
                },
                'PE': {
                    'PName': row[18],
                    'PRole': row[19],
                    'PDur': row[20],
                    'PDes': row[21],
                    'PNum': row[22]
                },
                'WE': {
                    'WCom': row[23],
                    'WPos': row[24],
                    'WDur': row[25],
                    'WDes': row[26]
                },
                'Intro': row[27]
            }, 200

    @seeker.response(200, 'Success')
    @seeker.response(403, 'Invalid Token')
    @seeker.param('token', 'Auth Token')
    @seeker.expect(jobseeker_profile_details)
    @seeker.doc(description="This method is used to update the job seeker's profile")
    def put(self):
        token = request.args.get('token')
        data = json.loads(request.get_data())
        cursor = db.cursor()
        cursor.execute("SELECT * FROM USERS WHERE TOKEN = '{}';".format(token))
        row = cursor.fetchone()
        if row == None:
            return {"message": "Invalid Token"}, 403
        else:
            categories = data.keys()
            if len(categories) == 0:
                return {"message": "profile updated"}, 200
            else:
                for category in categories:
                    if type(data[category]) == dict:
                        keys = data[category].keys()
                        for key in keys:
                            cursor.execute("UPDATE USERS SET {0} = '{1}' WHERE TOKEN = '{2}';".format(key, data[category][key], token))
                            db.commit()
                    else:
                        cursor.execute("UPDATE USERS SET {0} = '{1}' WHERE TOKEN = '{2}';".format(category, data[category], token))
                        db.commit()
                return {"message": "profile updated"}, 200


@employer.route('/employerPage', methods=['GET', 'PUT'])
class Employer(Resource):
    @employer.response(200, 'Success', employer_profile_details)
    @employer.response(403, 'Invalid Token')
    @employer.param('token', 'Auth Token')
    @employer.doc(description="This method is used to get the employer's profile details from the server")
    def get(self):
        token = request.args.get('token')
        cursor = db.cursor()
        cursor.execute("SELECT * FROM USERS WHERE TOKEN = '{}';".format(token))
        row = cursor.fetchone()
        if row == None:
            return {"message": "Invalid Token"}, 403
        else:
            return {
                'first_name': row[3],
                'last_name': row[4],
                'company_name': row[28],
                'company_type': row[29],
                'tele': row[7],
                'email': row[8],
                'ABN': row[30],
                'post_code': row[31],
                'company_des': row[32]
            }, 200

    @employer.response(200, 'Success')
    @employer.response(403, 'Invalid Token')
    @employer.param('token', 'Auth Token')
    @employer.expect(employer_profile_details)
    @employer.doc(description="This method is used to update the employer's profile details")
    def put(self):
        token = request.args.get('token')
        data = json.loads(request.get_data())
        cursor = db.cursor()
        cursor.execute("SELECT * FROM USERS WHERE TOKEN = '{}';".format(token))
        row = cursor.fetchone()
        if row == None:
            return {"message": "Invalid Token"}, 403
        else:
            keys = data.keys()
            if len(keys) == 0:
                return {"message": "profile updated"}, 200
            else:
                for key in keys:
                    cursor.execute("UPDATE USERS SET {0} = '{1}' WHERE TOKEN = '{2}';".format(key, data[key], token))
                    db.commit()
                return {"message": "profile updated"}, 200