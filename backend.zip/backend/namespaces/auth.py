from flask_restplus import Resource
from flask import request
from util.models import *
from util.database import *
import json

auth = api.namespace('auth', description='Authentication Services')


@auth.route('/login', methods=['GET', 'POST'])
class Login(Resource):
    @auth.response(200, 'Login successfully', token_details)
    @auth.response(400, 'Incorrect password')
    @auth.response(403, 'Username error')
    @auth.expect(login_details)
    @auth.doc(description='This method is used to verify '
                          'whether the username and password are correct in order to achieve the login functionality.')
    def post(self):
        login_data = json.loads(request.get_data())
        email = login_data['email']
        password = login_data['password']
        cursor = db.cursor()
        cursor.execute('SELECT EMAIL FROM USERS;')
        results = cursor.fetchall()
        results = list(results)
        emails = []
        for result in results:
            emails.append(result[0])
        if email not in emails:
            return {"message": "the username does not exist."}, 403
        else:
            cursor.execute("SELECT PASSWORD FROM USERS WHERE EMAIL = '{}';".format(email))
            password_result = cursor.fetchone()
            if password == password_result[0]:
                t = gen_token()
                cursor.execute("UPDATE USERS SET TOKEN = '{0}' WHERE EMAIL = '{1}';".format(t, email))
                db.commit()
                cursor.execute("SELECT ROLE FROM USERS WHERE EMAIL = '{}';".format(email))
                role_result = cursor.fetchone()
                role = role_result[0]
                return {
                        'token': t,
                        'role': role,
                        'email': email
                       }, 200
            else:
                return {"message": "the password is not correct"}, 400


# Job seeker register
@auth.route('/seekerRegister', methods=['GET', 'POST'])
class SeekerRegister(Resource):
    @auth.response(200, 'Register successfully', token_details)
    @auth.response(400, 'Username error')
    @auth.expect(jobseeker_register_details)
    @auth.doc(description='This method is used to create a new job seeker account.')
    def post(self):
        seeker_register_data = json.loads(request.get_data())
        first_name = seeker_register_data['first_name']
        last_name = seeker_register_data['last_name']
        email = seeker_register_data['email']
        password = seeker_register_data['password']
        phone_number = seeker_register_data['phone_number']
        role_id = 1
        cursor = db.cursor()
        cursor.execute('SELECT EMAIL FROM USERS;')
        results = cursor.fetchall()
        results = list(results)
        emails = []
        for result in results:
            emails.append(result[0])
        if email in emails:
            return {"message": "this email has already been registered."}, 400
        else:
            t = gen_token()
            cursor.execute("INSERT INTO USERS (ROLE, TOKEN, FIRST_NAME, LAST_NAME, EMAIL, PASSWORD, TELE, SRC) \
                           VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}');".format(role_id, t, first_name, last_name, email, password, phone_number, icon))
            db.commit()
            return {"token": t}, 200


@auth.route('/employerRegister', methods=['GET', 'POST'])
class EmployerRegister(Resource):
    @auth.response(200, 'Register successfully', token_details)
    @auth.response(400, 'Username error')
    @auth.expect(employer_register_details)
    @auth.doc(description='This method is used to create a new company account.')
    def post(self):
        employer_register_data = json.loads(request.get_data())
        first_name = employer_register_data['first_name']
        last_name = employer_register_data['last_name']
        email = employer_register_data['coEmail']
        password = employer_register_data['password']
        phone_number = employer_register_data['phoneNo']
        company_name = employer_register_data['coName']
        abn = employer_register_data['ABN']
        post_code = employer_register_data['post_code']
        role_id = 2
        cursor = db.cursor()
        cursor.execute('SELECT EMAIL FROM USERS;')
        results = cursor.fetchall()
        results = list(results)
        emails = []
        for result in results:
            emails.append(result[0])
        if email in emails:
            return {"message": "this email has already been registered."}, 400
        else:
            t = gen_token()
            cursor.execute("INSERT INTO USERS (ROLE, TOKEN, FIRST_NAME, LAST_NAME, EMAIL, PASSWORD, TELE, COMPANY_NAME,\
                           ABN, POST_CODE) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}');".format(role_id, t, first_name, last_name, email, password, phone_number, company_name, abn, post_code))
            db.commit()
            return {"token": t}, 200