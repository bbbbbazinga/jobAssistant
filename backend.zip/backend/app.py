from flask import Flask
from flask_restplus import Api
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
api = Api(app, default='9900Project', title='9900Project Api', description='This api works for the recruit assistant website')